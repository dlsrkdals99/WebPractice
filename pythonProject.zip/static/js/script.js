console.log("사전 프로젝트에 오신 것을 환영합니다!");

document.addEventListener('DOMContentLoaded', () => {
    const toggleButton = document.getElementById('toggle-theme');

    // 페이지 로드 시 저장된 테마 적용
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
        toggleButton.innerText = '라이트 모드';
    }

    // 버튼 클릭 이벤트
    toggleButton.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        const theme = document.body.classList.contains('dark-mode') ? 'dark' : 'light';
        toggleButton.innerText = theme === 'dark' ? '라이트 모드' : '다크 모드';
        localStorage.setItem('theme', theme);
    });
});
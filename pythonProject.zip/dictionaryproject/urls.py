from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # 관리자 페이지
    path('admin/', admin.site.urls),
    # 사전 관련 URL
    path('items/', include('dictionary.urls')),
    # 계정 관련 URL
    path('accounts/', include('accounts.urls')),
    # 기본 URL을 'items/'로 설정
    path('', include('dictionary.urls')),
]

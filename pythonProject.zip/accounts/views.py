from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required

# 회원가입
def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            try:
                user = form.save()
                username = form.cleaned_data.get('username')
                raw_password = form.cleaned_data.get('password1')
                user = authenticate(username=username, password=raw_password)
                login(request, user)
                return redirect('/')  # 회원가입 후 홈으로 이동
            except IntegrityError:
                form.add_error('username', '이미 사용 중인 사용자 이름입니다.')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

# 로그아웃
@login_required
def user_logout(request):
    logout(request)
    return redirect('login')  # 로그아웃 후 로그인 페이지로 이동

# 로그인 (Django 기본 로그인 뷰 사용 가능)
def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('/')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})
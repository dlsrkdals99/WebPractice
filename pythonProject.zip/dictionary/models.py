from django.db import models
from django.contrib.auth.models import User

class Item(models.Model):
    name = models.CharField(max_length=100, verbose_name='이름')
    durability = models.IntegerField(verbose_name='내구도')
    self_heal_speed = models.IntegerField(verbose_name='자기치료속도')
    others_heal_speed = models.IntegerField(verbose_name='타인치료속도')
    description = models.TextField(verbose_name='설명')

    def __str__(self):
        return self.name

class Addon(models.Model):
    name = models.CharField(max_length=100, verbose_name='이름')
    durability = models.IntegerField(verbose_name='내구도')
    skill_check_increase = models.IntegerField(verbose_name='스킬체크 증가')
    healing_speed_increase = models.IntegerField(verbose_name='치료 속도 증가')
    great_skill_bonus = models.IntegerField(verbose_name='대성공 보너스')
    skill_check_size_increase = models.IntegerField(verbose_name='스킬체크 크기 증가')
    skill_check_frequency_increase = models.IntegerField(verbose_name='스킬체크 빈도 증가')
    description = models.TextField(verbose_name='설명')

    def __str__(self):
        return self.name

class Bookmark(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='dictionary_bookmarks')
    query = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.query}"

class SearchHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='dictionary_search_histories')
    word = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.word}"

class Word(models.Model):
    term = models.CharField(max_length=255, verbose_name='단어')
    definition = models.TextField(verbose_name='정의')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='생성일')

    def __str__(self):
        return self.term
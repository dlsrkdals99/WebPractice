from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.HomeView.as_view(), name='home'),  # 홈
    path('board/', include('board.urls')),  # 게시판 URL
    path('accounts/', include('django.contrib.auth.urls')),  # 로그인/로그아웃
    path('item_list/', views.item_list, name='item_list'),
    path('items/create/', views.ItemCreateView.as_view(), name='item_create'),
    path('items/<int:pk>/update/', views.ItemUpdateView.as_view(), name='item_update'),
    path('items/<int:pk>/delete/', views.ItemDeleteView.as_view(), name='item_delete'),
    path('addons/', views.AddonListView.as_view(), name='addon_list'),
    path('addons/create/', views.AddonCreateView.as_view(), name='addon_create'),
    path('addons/<int:pk>/update/', views.AddonUpdateView.as_view(), name='addon_update'),
    path('addons/<int:pk>/delete/', views.AddonDeleteView.as_view(), name='addon_delete'),
    path('combine/', views.combine_view, name='combine_view'),
    path('add_bookmark/', views.add_bookmark, name='add_bookmark'),
    path('remove_bookmark/', views.remove_bookmark, name='remove_bookmark'),
    path('search_statistics/', views.search_statistics, name='search_statistics'),
    path('set_theme/<str:theme>/', views.set_theme, name='set_theme'),
]
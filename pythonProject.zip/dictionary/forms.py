from django import forms
from .models import Item, Addon

class ItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = ['name', 'durability', 'self_heal_speed', 'others_heal_speed', 'description']
        labels = {
            'name': '이름',
            'durability': '내구도',
            'self_heal_speed': '자기치료속도',
            'others_heal_speed': '타인치료속도',
            'description': '설명',
        }

class AddonForm(forms.ModelForm):
    class Meta:
        model = Addon
        fields = [
            'name', 'durability', 'skill_check_increase', 'healing_speed_increase',
            'great_skill_bonus', 'skill_check_size_increase', 'skill_check_frequency_increase',
            'description'
        ]
        labels = {
            'name': '이름',
            'durability': '내구도',
            'skill_check_increase': '스킬체크 증가',
            'healing_speed_increase': '치료 속도 증가',
            'great_skill_bonus': '대성공 보너스',
            'skill_check_size_increase': '스킬체크 크기 증가',
            'skill_check_frequency_increase': '스킬체크 빈도 증가',
            'description': '설명',
        }
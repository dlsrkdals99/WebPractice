from django.contrib import admin
from .models import Item, Addon

admin.site.register(Item)
admin.site.register(Addon)
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from .models import Item, Addon, Bookmark, SearchHistory
from .forms import ItemForm, AddonForm
from django.http import JsonResponse
from django.db.models import Count

class HomeView(ListView):
    model = Item
    template_name = 'dictionary/home.html'
    context_object_name = 'items'  # Ensure this line is added

class ItemListView(ListView):
    model = Item
    template_name = 'dictionary/item_list.html'
    context_object_name = 'items'  # Ensure this line is added

class ItemCreateView(CreateView):
    model = Item
    form_class = ItemForm
    template_name = 'dictionary/item_form.html'
    success_url = reverse_lazy('item_list')

class ItemUpdateView(UpdateView):
    model = Item
    form_class = ItemForm
    template_name = 'dictionary/item_form.html'
    success_url = reverse_lazy('item_list')

class ItemDeleteView(DeleteView):
    model = Item
    template_name = 'dictionary/item_confirm_delete.html'
    success_url = reverse_lazy('item_list')

class AddonListView(ListView):
    model = Addon
    template_name = 'dictionary/addon_list.html'
    context_object_name = 'addons'  # Ensure this line is added

class AddonCreateView(CreateView):
    model = Addon
    form_class = AddonForm
    template_name = 'dictionary/addon_form.html'
    success_url = reverse_lazy('addon_list')

class AddonUpdateView(UpdateView):
    model = Addon
    form_class = AddonForm
    template_name = 'dictionary/addon_form.html'
    success_url = reverse_lazy('addon_list')

class AddonDeleteView(DeleteView):
    model = Addon
    template_name = 'dictionary/addon_confirm_delete.html'
    success_url = reverse_lazy('addon_list')

def item_list(request):
    items = Item.objects.all()  # 모든 아이템을 가져옵니다.
    return render(request, 'dictionary/item_list.html', {'items': items})

# Theme 설정
def set_theme(request, theme):
    if theme in ['dark', 'light']:
        request.session['theme'] = theme
    return redirect(request.META.get('HTTP_REFERER', '/'))

# 북마크 추가
def add_bookmark(request):
    if request.method == "POST" and request.user.is_authenticated:
        word = request.POST.get("word")
        Bookmark.objects.create(user=request.user, word=word)
        return JsonResponse({"message": "북마크 추가 완료"})
    return JsonResponse({"message": "로그인이 필요합니다"}, status=401)

# 북마크 제거
def remove_bookmark(request):
    if request.method == "POST" and request.user.is_authenticated:
        word = request.POST.get("word")
        Bookmark.objects.filter(user=request.user, word=word).delete()
        return JsonResponse({"message": "북마크 제거 완료"})
    return JsonResponse({"message": "로그인이 필요합니다"}, status=401)

# 검색 기능 및 히스토리 통계 추가
def search_statistics(request):
    stats = SearchHistory.objects.values("word").annotate(count=Count("id"))
    return render(request, 'dictionary/search_statistics.html', {"stats": stats})

# 아이템과 애드온 결합 보기
def combine_view(request):
    if request.method == "POST":
        selected_item_id = request.POST.get('item')
        selected_addon1_id = request.POST.get('addon1')
        selected_addon2_id = request.POST.get('addon2')

        item = Item.objects.get(id=selected_item_id)
        addon1 = Addon.objects.get(id=selected_addon1_id)
        addon2 = Addon.objects.get(id=selected_addon2_id)

        combined_effect = f"{item.name} combined with {addon1.name} and {addon2.name}"

        total_durability = item.durability + addon1.durability + addon2.durability
        total_self_heal_speed = item.self_heal_speed
        total_others_heal_speed = item.others_heal_speed + addon1.healing_speed_increase + addon2.healing_speed_increase
        total_skill_check_increase = addon1.skill_check_increase + addon2.skill_check_increase
        total_great_skill_bonus = addon1.great_skill_bonus + addon2.great_skill_bonus
        total_skill_check_size_increase = addon1.skill_check_size_increase + addon2.skill_check_size_increase
        total_skill_check_frequency_increase = addon1.skill_check_frequency_increase + addon2.skill_check_frequency_increase

        combined_results = [{
            'item': item,
            'addon1': addon1,
            'addon2': addon2,
            'combined_effect': combined_effect,
            'total_durability': total_durability,
            'total_self_heal_speed': total_self_heal_speed,
            'total_others_heal_speed': total_others_heal_speed,
            'total_skill_check_increase': total_skill_check_increase,
            'total_great_skill_bonus': total_great_skill_bonus,
            'total_skill_check_size_increase': total_skill_check_size_increase,
            'total_skill_check_frequency_increase': total_skill_check_frequency_increase
        }]

        return render(request, 'dictionary/combined_result.html', {'combined_results': combined_results})

    items = Item.objects.all()
    addons = Addon.objects.all()
    return render(request, 'dictionary/combine.html', {'items': items, 'addons': addons})
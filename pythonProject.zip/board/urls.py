from django.urls import path
from . import views

urlpatterns = [
    path('', views.board_list, name='board_list'),  # 게시글 목록
    path('create/', views.board_create, name='board_create'),  # 게시글 작성
    path('<int:pk>/', views.board_detail, name='board_detail'),  # 게시글 상세 보기
    path('add_comment/<int:post_id>/', views.add_comment, name='add_comment'),  # 댓글 작성
    path('add_reply/<int:comment_id>/', views.add_reply, name='add_reply'),  # 답글 작성
    path('bookmark/<int:post_id>/', views.toggle_bookmark, name='toggle_bookmark'),  # 북마크 추가/삭제
    path('comment/<int:post_id>/', views.post_comment, name='post_comment'),  # 댓글 폼 처리
    path('bookmarks/', views.bookmark_list, name='bookmark_list'),  # 북마크 목록 보기
]

from django.shortcuts import render, get_object_or_404, redirect
from .models import Post, Comment, Reply, Bookmark
from .forms import PostForm, CommentForm
from django.contrib.auth.decorators import login_required

# 게시글 목록 보기
def board_list(request):
    posts = Post.objects.all()
    return render(request, 'board/board_list.html', {'posts': posts})

# 게시글 작성
@login_required
def board_create(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('board_list')
    else:
        form = PostForm()
    return render(request, 'board/board_create.html', {'form': form})

# 게시글 상세 보기
def board_detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    comments = post.comments.all()
    is_bookmarked = Bookmark.objects.filter(user=request.user, content=post).exists() if request.user.is_authenticated else False
    return render(request, 'board/board_detail.html', {
        'post': post,
        'comments': comments,
        'is_bookmarked': is_bookmarked,
    })

# 댓글 추가
@login_required
def add_comment(request, post_id):
    if request.method == "POST":
        post = get_object_or_404(Post, id=post_id)
        content = request.POST.get("content")
        if content:  # 내용이 있을 때만 댓글 생성
            Comment.objects.create(user=request.user, post=post, content=content)
        return redirect('board_detail', pk=post_id)

# 답글 추가
@login_required
def add_reply(request, comment_id):
    if request.method == "POST":
        comment = get_object_or_404(Comment, id=comment_id)
        content = request.POST.get("content")
        if content:  # 내용이 있을 때만 답글 생성
            Reply.objects.create(user=request.user, comment=comment, content=content)
        return redirect('board_detail', pk=comment.post.id)

# 북마크 추가/삭제
@login_required
def toggle_bookmark(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    bookmark, created = Bookmark.objects.get_or_create(user=request.user, content=post)
    if not created:  # 이미 존재하면 삭제
        bookmark.delete()
    return redirect('board_detail', pk=post_id)

# 댓글 폼 처리 (추가 댓글 작성)
@login_required
def post_comment(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    form = CommentForm(request.POST)
    if form.is_valid():
        comment = form.save(commit=False)
        comment.post = post
        comment.user = request.user
        comment.save()
    return redirect('board_detail', pk=post_id)

# 북마크 목록 보기
@login_required
def bookmark_list(request):
    bookmarks = Bookmark.objects.filter(user=request.user)
    return render(request, 'board/bookmark_list.html', {'bookmarks': bookmarks})
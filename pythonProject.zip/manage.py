#!/usr/bin/env python
import os
import sys

def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dictionaryproject.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Django를 가져올 수 없습니다. Django가 설치되어 있고 "
            "PYTHONPATH 환경 변수에 사용 가능합니까? "
            "가상 환경을 활성화하는 것을 잊으셨습니까?"
        ) from exc
    execute_from_command_line(sys.argv)

if __name__ == '__main__':
    main()